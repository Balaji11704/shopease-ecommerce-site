/* ShopEase - Home Page JS */

var currentSlide = 0;
var totalSlides = 4;
var sliderInterval;

function goToSlide(index) {
    var slides = document.querySelectorAll('.offer-slide');
    var dots   = document.querySelectorAll('.dot');
    if (!slides.length) return;
    slides[currentSlide].classList.remove('active');
    slides[currentSlide].classList.add('exit');
    var prev = currentSlide;
    setTimeout(function() { slides[prev].classList.remove('exit'); }, 500);
    currentSlide = ((index % totalSlides) + totalSlides) % totalSlides;
    slides[currentSlide].classList.add('active');
    dots.forEach(function(d) { d.classList.remove('active'); });
    if (dots[currentSlide]) dots[currentSlide].classList.add('active');
}

function slideOffers(dir) {
    goToSlide(currentSlide + dir);
    resetSliderTimer();
}

function resetSliderTimer() {
    clearInterval(sliderInterval);
    sliderInterval = setInterval(function() { goToSlide(currentSlide + 1); }, 4500);
}

/* Countdown - slide 1 flash sale */
function startCountdown() {
    var end = new Date();
    end.setHours(end.getHours() + 8, end.getMinutes() + 45, end.getSeconds());
    function tick() {
        var diff = Math.max(0, end - new Date());
        var h1 = document.getElementById('h1');
        var m1 = document.getElementById('m1');
        var s1 = document.getElementById('s1');
        if (h1) h1.textContent = String(Math.floor(diff/3600000)).padStart(2,'0');
        if (m1) m1.textContent = String(Math.floor((diff%3600000)/60000)).padStart(2,'0');
        if (s1) s1.textContent = String(Math.floor((diff%60000)/1000)).padStart(2,'0');
    }
    tick();
    setInterval(tick, 1000);
}

/* Deals section countdown */
function startDealsTimer() {
    var end = new Date();
    end.setHours(end.getHours() + 11, end.getMinutes() + 59, end.getSeconds() + 59);
    function tick() {
        var diff = Math.max(0, end - new Date());
        var dh = document.getElementById('dh');
        var dm = document.getElementById('dm');
        var ds = document.getElementById('ds');
        if (dh) dh.textContent = String(Math.floor(diff/3600000)).padStart(2,'0');
        if (dm) dm.textContent = String(Math.floor((diff%3600000)/60000)).padStart(2,'0');
        if (ds) ds.textContent = String(Math.floor((diff%60000)/1000)).padStart(2,'0');
    }
    tick();
    setInterval(tick, 1000);
}

document.addEventListener('DOMContentLoaded', function() {
    if (document.querySelector('.offers-slider')) {
        sliderInterval = setInterval(function() { goToSlide(currentSlide + 1); }, 4500);
        startCountdown();
    }
    if (document.getElementById('dh')) {
        startDealsTimer();
    }
});
