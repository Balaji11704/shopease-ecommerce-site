package com.ecommerce.controller;

import com.ecommerce.config.AuthHelper;
import com.ecommerce.model.Product;
import com.ecommerce.service.CartService;
import com.ecommerce.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
public class HomeController {

    @Autowired private ProductService productService;
    @Autowired private CartService cartService;
    @Autowired private AuthHelper authHelper;

    // Home page — hero + slider + category cards + deals, NO product grid
    @GetMapping("/")
    public String home(Model model) {
        addCartCount(model);
        return "index";
    }

    // Category page — fetch products by category from DB
    @GetMapping("/category/{category}")
    public String categoryPage(@PathVariable String category, Model model) {
        List<Product> products = productService.getProductsByCategory(category);
        model.addAttribute("products", products);
        model.addAttribute("category", category);
        addCartCount(model);
        return "category";
    }

    // Product detail page
    @GetMapping("/product/{id}")
    public String productDetail(@PathVariable Integer id, Model model) {
        Optional<Product> productOpt = productService.getProductById(id);

        if (productOpt.isEmpty()) {
            return "redirect:/";
        }

        Product product = productOpt.get();
        model.addAttribute("product", product);

        // Related products — same category, exclude current product
        List<Product> related = productService
                .getProductsByCategory(product.getCategory())
                .stream()
                .filter(p -> !p.getId().equals(id))
                .limit(4)
                .collect(Collectors.toList());

        model.addAttribute("related", related);
        addCartCount(model);
        return "product-detail";
    }

    // Search
    @GetMapping("/search")
    public String search(@RequestParam(required = false) String keyword, Model model) {
        if (keyword != null && !keyword.isBlank()) {
            model.addAttribute("products", productService.searchProducts(keyword));
            model.addAttribute("keyword", keyword);
        } else {
            model.addAttribute("products", productService.getAllProducts());
        }
        addCartCount(model);
        return "search";
    }

    private void addCartCount(Model model) {
        authHelper.getCurrentUser().ifPresent(u ->
                model.addAttribute("cartCount", cartService.getCartCount(u)));
    }
}
