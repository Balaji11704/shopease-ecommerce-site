# 🛍️ ShopEase - Spring Boot E-Commerce Application

Migrated from Java Servlets + JSP to **Spring Boot 3.2** with a modern, responsive UI.

---

## 🚀 Tech Stack

| Layer       | Technology                          |
|-------------|-------------------------------------|
| Backend     | Spring Boot 3.2, Spring MVC         |
| Security    | Spring Security 6 (BCrypt passwords)|
| Database    | Spring Data JPA + MySQL             |
| Templates   | Thymeleaf 3                         |
| UI          | Custom CSS, Font Awesome, Inter font|

---

## 📁 Project Structure

```
src/main/java/com/ecommerce/
├── EcommerceApplication.java       ← Main entry point
├── config/
│   ├── SecurityConfig.java         ← Spring Security setup
│   └── AuthHelper.java             ← Get current logged-in user
├── controller/
│   ├── HomeController.java         ← Product listing + search
│   ├── AuthController.java         ← Login / Register
│   ├── CartController.java         ← Cart CRUD (AJAX-enabled)
│   ├── OrderController.java        ← Checkout, place order, history
│   └── ProfileController.java      ← View + edit profile
├── model/
│   ├── User.java
│   ├── Product.java
│   ├── CartItem.java
│   ├── Order.java
│   └── OrderItem.java
├── repository/                     ← Spring Data JPA interfaces
├── service/                        ← Business logic layer

src/main/resources/
├── templates/                      ← Thymeleaf HTML templates
│   ├── index.html                  ← Home / product listing
│   ├── login.html
│   ├── register.html
│   ├── cart.html                   ← Dynamic cart with AJAX
│   ├── checkout.html
│   ├── order-confirmation.html
│   ├── orders.html
│   ├── profile.html
│   ├── edit-profile.html
│   ├── search.html
│   └── fragments/layout.html       ← Shared navbar + footer
├── static/
│   ├── css/style.css               ← Full modern UI stylesheet
│   └── js/main.js                  ← Cart AJAX + UI helpers
├── application.properties
└── schema.sql                      ← DB setup + sample data
```

---

## ⚙️ Setup Instructions

### 1. Database

```sql
-- Run schema.sql in MySQL Workbench or terminal:
mysql -u root -p < src/main/resources/schema.sql
```

### 2. Configure DB Credentials

Edit `src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/ecommerce_db
spring.datasource.username=root
spring.datasource.password=YOUR_PASSWORD_HERE
```

### 3. Build & Run

```bash
# Using Maven Wrapper
./mvnw spring-boot:run

# Or build JAR and run
./mvnw clean package
java -jar target/ecommerce-springboot-1.0.0.jar
```

### 4. Access the App

Open: **http://localhost:8080**

---

## ✅ What Changed from Servlet Version

| Old (Servlets)                  | New (Spring Boot)                           |
|----------------------------------|---------------------------------------------|
| `HttpServlet` + `doPost/doGet`  | `@Controller` + `@GetMapping/@PostMapping`  |
| Manual JDBC (`DBConnection`)     | Spring Data JPA repositories                |
| JSP templates                    | Thymeleaf HTML templates                    |
| Plain-text passwords in DB       | BCrypt password hashing (Spring Security)   |
| Manual session management        | Spring Security + session auto-management   |
| `web.xml` servlet mappings       | Auto-configured via annotations             |
| No CSRF / security               | Spring Security with full protection        |

---

## 🎨 UI Highlights

- Modern gradient hero section
- Responsive product grid with hover effects
- AJAX-powered cart updates (no page reload)
- Animated page transitions
- Mobile-friendly responsive design
- Toast notifications
- Polished auth pages with password toggle

---

## 🔑 Default Test Accounts

Register through the app — passwords are auto-hashed with BCrypt.

---

## 📌 Notes

- `spring.jpa.hibernate.ddl-auto=update` — JPA auto-creates/updates tables
- Run `schema.sql` manually first for sample product data
- The `category` column is new — existing DB rows will have NULL (safe)
