-- ================================================
-- ShopEase - MySQL Database Schema
-- Run this script to set up the database
-- ================================================

CREATE DATABASE IF NOT EXISTS ecommerce_db;
USE ecommerce_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    role VARCHAR(20) DEFAULT 'USER',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    image VARCHAR(500),
    price DECIMAL(10, 2) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cart table
CREATE TABLE IF NOT EXISTS user_cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT DEFAULT 1,
    UNIQUE KEY unique_user_product (user_id, product_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_price DECIMAL(10, 2),
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50) DEFAULT 'Pending',
    fullname VARCHAR(100),
    address TEXT,
    phone VARCHAR(20),
    productname TEXT,
    payment_method VARCHAR(50),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT,
    quantity INT,
    price DECIMAL(10, 2),
    product_name VARCHAR(200),
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
);

-- ================================================
-- Sample Product Data
-- ================================================
INSERT INTO products (name, image, price, description, category) VALUES
('Apple iPhone 15 Pro', 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400', 129999.00, 'Latest iPhone with titanium design and A17 Pro chip. Features ProMotion display and advanced camera system.', 'Electronics'),
('Sony WH-1000XM5 Headphones', 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400', 24999.00, 'Industry-leading noise canceling headphones with 30hr battery life and crystal-clear calling.', 'Electronics'),
('Running Shoes - Nike Air Max', 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400', 8999.00, 'Lightweight performance running shoes with Air Max cushioning technology for maximum comfort.', 'Footwear'),
('Mechanical Keyboard RGB', 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=400', 5499.00, 'Tactile mechanical switches with full RGB backlight. Perfect for gaming and typing enthusiasts.', 'Electronics'),
('Leather Crossbody Bag', 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=400', 3299.00, 'Genuine leather crossbody bag with multiple compartments. Elegant design for everyday use.', 'Fashion'),
('4K Webcam Pro', 'https://images.unsplash.com/photo-1587826026600-4c33a5f3e6e4?w=400', 7999.00, 'Ultra HD 4K webcam with built-in ring light and noise-canceling microphone. Ideal for streaming.', 'Electronics'),
('Minimalist Watch', 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400', 4599.00, 'Sleek minimalist watch with sapphire crystal glass and stainless steel strap. Water resistant.', 'Fashion'),
('Yoga Mat Premium', 'https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=400', 1999.00, 'Non-slip premium yoga mat with alignment lines. 6mm thick for extra joint support.', 'Sports');
