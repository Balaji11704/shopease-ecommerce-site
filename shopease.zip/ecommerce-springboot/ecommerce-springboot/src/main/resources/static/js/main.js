/* ShopEase - Main JS */

// Mobile menu toggle
function toggleMobileMenu() {
    const search = document.querySelector('.nav-search');
    if (search) {
        search.style.display = search.style.display === 'flex' ? 'none' : 'flex';
        search.style.position = 'absolute';
        search.style.top = '68px';
        search.style.left = '0';
        search.style.right = '0';
        search.style.width = '100%';
        search.style.borderRadius = '0';
        search.style.zIndex = '999';
        search.style.background = 'white';
        search.style.padding = '0.75rem 1rem';
        search.style.boxShadow = '0 4px 12px rgba(0,0,0,0.1)';
    }
}

// Flash message auto-dismiss
document.addEventListener('DOMContentLoaded', () => {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-8px)';
            setTimeout(() => alert.remove(), 500);
        }, 4000);
    });

    // Payment option selection highlight
    document.querySelectorAll('.payment-option input[type="radio"]').forEach(radio => {
        radio.addEventListener('change', () => {
            document.querySelectorAll('.payment-card').forEach(c => c.classList.remove('selected'));
            if (radio.checked) radio.nextElementSibling.classList.add('selected');
        });
    });

    // Product card enter animation
    const cards = document.querySelectorAll('.product-card');
    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry, i) => {
                if (entry.isIntersecting) {
                    entry.target.style.animation = `fadeIn 0.4s ease ${i * 0.05}s both`;
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        cards.forEach(card => observer.observe(card));
    }
});

// Add to cart feedback toast
function showToast(msg, type = 'success') {
    const existing = document.querySelector('.toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i> ${msg}`;
    toast.style.cssText = `
        position: fixed; bottom: 1.5rem; right: 1.5rem; z-index: 9999;
        background: ${type === 'success' ? '#10b981' : '#ef4444'};
        color: white; padding: 0.9rem 1.3rem;
        border-radius: 12px; font-weight: 600; font-size: 0.9rem;
        box-shadow: 0 8px 24px rgba(0,0,0,0.2);
        display: flex; align-items: center; gap: 0.5rem;
        animation: slideUp 0.3s ease;
    `;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(10px)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}
