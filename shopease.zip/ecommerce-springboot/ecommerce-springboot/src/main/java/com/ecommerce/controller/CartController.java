package com.ecommerce.controller;

import com.ecommerce.config.AuthHelper;
import com.ecommerce.model.CartItem;
import com.ecommerce.model.User;
import com.ecommerce.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/cart")
public class CartController {

    @Autowired private CartService cartService;
    @Autowired private AuthHelper authHelper;

    @GetMapping
    public String viewCart(Model model) {
        User user = authHelper.getCurrentUser().orElse(null);
        if (user == null) return "redirect:/login";

        List<CartItem> items = cartService.getCartItems(user);
        double total = cartService.getCartTotal(user);

        model.addAttribute("cartItems", items);
        model.addAttribute("cartTotal", total);
        model.addAttribute("cartCount", items.size());
        return "cart";
    }

    @PostMapping("/add")
    public String addToCart(@RequestParam Integer productId,
                            @RequestParam(defaultValue = "1") int quantity) {
        User user = authHelper.getCurrentUser().orElse(null);
        if (user == null) return "redirect:/login";
        cartService.addToCart(user, productId, quantity);
        return "redirect:/cart";
    }

    @PostMapping("/update")
    @ResponseBody
    public ResponseEntity<?> updateCart(@RequestParam Integer productId,
                                        @RequestParam String updateType) {
        User user = authHelper.getCurrentUser().orElse(null);
        if (user == null) return ResponseEntity.status(401).build();
        cartService.updateQuantity(user, productId, updateType);
        List<CartItem> items = cartService.getCartItems(user);
        double total = items.stream().mapToDouble(CartItem::getSubtotal).sum();
        return ResponseEntity.ok(Map.of("total", total, "count", items.size()));
    }

    @PostMapping("/remove")
    @ResponseBody
    public ResponseEntity<?> removeFromCart(@RequestParam Integer productId) {
        User user = authHelper.getCurrentUser().orElse(null);
        if (user == null) return ResponseEntity.status(401).build();
        cartService.removeFromCart(user, productId);
        List<CartItem> items = cartService.getCartItems(user);
        double total = items.stream().mapToDouble(CartItem::getSubtotal).sum();
        return ResponseEntity.ok(Map.of("total", total, "count", items.size()));
    }
}
