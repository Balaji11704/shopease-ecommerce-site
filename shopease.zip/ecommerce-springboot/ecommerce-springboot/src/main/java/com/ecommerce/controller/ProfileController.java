package com.ecommerce.controller;

import com.ecommerce.config.AuthHelper;
import com.ecommerce.model.User;
import com.ecommerce.service.CartService;
import com.ecommerce.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/profile")
public class ProfileController {

    @Autowired private UserService userService;
    @Autowired private AuthHelper authHelper;
    @Autowired private CartService cartService;

    @GetMapping
    public String profilePage(Model model) {
        User user = authHelper.getCurrentUser().orElse(null);
        if (user == null) return "redirect:/login";
        model.addAttribute("currentUser", user);
        model.addAttribute("cartCount", cartService.getCartCount(user));
        return "profile";
    }

    @GetMapping("/edit")
    public String editProfilePage(Model model) {
        User user = authHelper.getCurrentUser().orElse(null);
        if (user == null) return "redirect:/login";
        model.addAttribute("currentUser", user);
        model.addAttribute("cartCount", cartService.getCartCount(user));
        return "edit-profile";
    }

    @PostMapping("/update")
    public String updateProfile(@RequestParam String username,
                                @RequestParam String phone,
                                @RequestParam String address,
                                RedirectAttributes ra) {
        User user = authHelper.getCurrentUser().orElse(null);
        if (user == null) return "redirect:/login";

        user.setUsername(username);
        user.setPhone(phone);
        user.setAddress(address);
        userService.updateUser(user);

        ra.addFlashAttribute("success", "Profile updated successfully!");
        return "redirect:/profile";
    }
}
