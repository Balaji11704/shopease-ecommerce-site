package com.ecommerce.controller;

import com.ecommerce.config.AuthHelper;
import com.ecommerce.model.*;
import com.ecommerce.service.CartService;
import com.ecommerce.service.OrderService;
import com.ecommerce.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

@Controller
public class OrderController {

    @Autowired private OrderService orderService;
    @Autowired private CartService cartService;
    @Autowired private ProductService productService;
    @Autowired private AuthHelper authHelper;

    // Checkout from cart
    @GetMapping("/checkout")
    public String checkoutPage(@RequestParam(required = false) Boolean buynow,
                               @RequestParam(required = false) Integer productId,
                               @RequestParam(required = false, defaultValue = "1") int qty,
                               Model model) {
        User user = authHelper.getCurrentUser().orElse(null);
        if (user == null) return "redirect:/login";

        List<CartItem> items;
        if (Boolean.TRUE.equals(buynow) && productId != null) {
            Product p = productService.getProductById(productId).orElse(null);
            if (p == null) return "redirect:/";
            CartItem tempItem = new CartItem(user, p, qty);
            items = Collections.singletonList(tempItem);
            model.addAttribute("isBuyNow", true);
            model.addAttribute("buyNowProductId", productId);
            model.addAttribute("buyNowQty", qty);
        } else {
            items = cartService.getCartItems(user);
            if (items.isEmpty()) return "redirect:/cart";
        }

        double total = items.stream().mapToDouble(CartItem::getSubtotal).sum();
        model.addAttribute("checkoutItems", items);
        model.addAttribute("checkoutTotal", total);
        model.addAttribute("currentUser", user);
        model.addAttribute("cartCount", cartService.getCartCount(user));
        return "checkout";
    }

    // Place order
    @PostMapping("/order/place")
    public String placeOrder(@RequestParam String fullname,
                             @RequestParam String address,
                             @RequestParam String phone,
                             @RequestParam String paymentMethod,
                             @RequestParam(required = false) Boolean buynow,
                             @RequestParam(required = false) Integer buyNowProductId,
                             @RequestParam(required = false, defaultValue = "1") int buyNowQty) {
        User user = authHelper.getCurrentUser().orElse(null);
        if (user == null) return "redirect:/login";

        List<CartItem> items;
        boolean clearCart;

        if (Boolean.TRUE.equals(buynow) && buyNowProductId != null) {
            Product p = productService.getProductById(buyNowProductId).orElse(null);
            if (p == null) return "redirect:/";
            CartItem tempItem = new CartItem(user, p, buyNowQty);
            items = Collections.singletonList(tempItem);
            clearCart = false;
        } else {
            items = cartService.getCartItems(user);
            if (items.isEmpty()) return "redirect:/cart";
            clearCart = true;
        }

        Order order = orderService.placeOrder(user, fullname, address, phone, paymentMethod, items, clearCart);
        return "redirect:/order/confirmation/" + order.getId() + "?payment=" + paymentMethod;
    }

    // Order confirmation
    @GetMapping("/order/confirmation/{orderId}")
    public String orderConfirmation(@PathVariable Integer orderId,
                                    @RequestParam(required = false) String payment,
                                    Model model) {
        User user = authHelper.getCurrentUser().orElse(null);
        if (user == null) return "redirect:/login";

        Order order = orderService.getOrderById(orderId).orElse(null);
        if (order == null || !order.getUser().getId().equals(user.getId())) return "redirect:/";

        model.addAttribute("order", order);
        model.addAttribute("paymentMethod", payment);
        model.addAttribute("cartCount", cartService.getCartCount(user));
        return "order-confirmation";
    }

    // Order history
    @GetMapping("/orders")
    public String myOrders(Model model) {
        User user = authHelper.getCurrentUser().orElse(null);
        if (user == null) return "redirect:/login";

        model.addAttribute("orders", orderService.getOrdersByUser(user));
        model.addAttribute("cartCount", cartService.getCartCount(user));
        return "orders";
    }
}
