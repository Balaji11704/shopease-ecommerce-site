package com.ecommerce.service;

import com.ecommerce.model.CartItem;
import com.ecommerce.model.Product;
import com.ecommerce.model.User;
import com.ecommerce.repository.CartRepository;
import com.ecommerce.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private ProductRepository productRepository;

    public List<CartItem> getCartItems(User user) {
        return cartRepository.findByUser(user);
    }

    public int getCartCount(User user) {
        return cartRepository.countByUser(user);
    }

    @Transactional
    public void addToCart(User user, Integer productId, int quantity) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        Optional<CartItem> existing = cartRepository.findByUserAndProduct(user, product);

        if (existing.isPresent()) {
            CartItem item = existing.get();
            item.setQuantity(item.getQuantity() + quantity);
            cartRepository.save(item);
        } else {
            cartRepository.save(new CartItem(user, product, quantity));
        }
    }

    @Transactional
    public void updateQuantity(User user, Integer productId, String updateType) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        cartRepository.findByUserAndProduct(user, product).ifPresent(item -> {
            if ("increase".equals(updateType)) {
                item.setQuantity(item.getQuantity() + 1);
                cartRepository.save(item);
            } else if ("decrease".equals(updateType) && item.getQuantity() > 1) {
                item.setQuantity(item.getQuantity() - 1);
                cartRepository.save(item);
            }
        });
    }

    @Transactional
    public void removeFromCart(User user, Integer productId) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        cartRepository.findByUserAndProduct(user, product)
                .ifPresent(cartRepository::delete);
    }

    @Transactional
    public void clearCart(User user) {
        cartRepository.deleteByUser(user);
    }

    public double getCartTotal(User user) {
        return getCartItems(user).stream()
                .mapToDouble(CartItem::getSubtotal)
                .sum();
    }
}
