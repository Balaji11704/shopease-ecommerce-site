package com.ecommerce.controller;

import com.ecommerce.config.AuthHelper;
import com.ecommerce.model.User;
import com.ecommerce.service.CartService;
import com.ecommerce.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;

@Controller
public class HomeController {

    @Autowired private ProductService productService;
    @Autowired private CartService cartService;
    @Autowired private AuthHelper authHelper;

    @GetMapping("/")
    public String home(@RequestParam(required = false) String search, Model model) {
        if (search != null && !search.isBlank()) {
            model.addAttribute("products", productService.searchProducts(search));
            model.addAttribute("search", search);
        } else {
            model.addAttribute("products", productService.getAllProducts());
        }
        addCartCount(model);
        return "index";
    }

    @GetMapping("/search")
    public String search(@RequestParam(required = false) String keyword, Model model) {
        if (keyword != null && !keyword.isBlank()) {
            model.addAttribute("products", productService.searchProducts(keyword));
            model.addAttribute("keyword", keyword);
        } else {
            model.addAttribute("products", productService.getAllProducts());
        }
        addCartCount(model);
        return "search";
    }

    private void addCartCount(Model model) {
        authHelper.getCurrentUser().ifPresent(u -> model.addAttribute("cartCount", cartService.getCartCount(u)));
    }
}
