package com.ecommerce.service;

import com.ecommerce.model.*;
import com.ecommerce.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CartService cartService;

    public List<Order> getOrdersByUser(User user) {
        return orderRepository.findByUserOrderByOrderDateDesc(user);
    }

    public Optional<Order> getOrderById(Integer id) {
        return orderRepository.findById(id);
    }

    @Transactional
    public Order placeOrder(User user, String fullname, String address, String phone,
                            String paymentMethod, List<CartItem> items, boolean clearCart) {

        Order order = new Order();
        order.setUser(user);
        order.setFullname(fullname);
        order.setAddress(address);
        order.setPhone(phone);
        order.setPaymentMethod(paymentMethod);
        order.setStatus("Pending");

        double total = 0;
        StringBuilder names = new StringBuilder();

        for (CartItem ci : items) {
            double subtotal = ci.getProduct().getPrice() * ci.getQuantity();
            total += subtotal;
            names.append(ci.getProduct().getName()).append(", ");

            OrderItem oi = new OrderItem(order, ci.getProduct(), ci.getQuantity(), ci.getProduct().getPrice());
            order.getItems().add(oi);
        }

        order.setTotalPrice(total);
        order.setProductName(names.toString().replaceAll(", $", ""));

        Order saved = orderRepository.save(order);

        if (clearCart) {
            cartService.clearCart(user);
        }

        return saved;
    }
}
